import { useState } from 'react'

function Features() {
  return (
    <>
      <div>
        <h1>Features</h1>
      </div>
    </>
  )
}

export default Features
